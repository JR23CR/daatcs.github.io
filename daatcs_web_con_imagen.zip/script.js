const products = [
  {
    name: "Taza personalizada 11oz",
    price: "Q45",
    image: "img/taza11oz.jpg.jpg"
  }
];

const phone = "50255965491";
const productList = document.getElementById("product-list");

products.forEach((product) => {
  const div = document.createElement("div");
  div.className = "product";
  div.innerHTML = `
    <img src="${product.image}" alt="${product.name}" />
    <h2>${product.name}</h2>
    <p>${product.price}</p>
    <a class="whatsapp-btn" href="https://wa.me/${phone}?text=Hola%2C%20quiero%20más%20información%20sobre%20${encodeURIComponent(product.name)}">Pedir por WhatsApp</a>
  `;
  productList.appendChild(div);
});
